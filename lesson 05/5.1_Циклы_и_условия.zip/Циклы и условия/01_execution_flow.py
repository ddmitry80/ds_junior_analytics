# -*- coding: utf-8 -*-

# Поток выполнения программ

print('дратути!')
x = 34
y = 43
print(x * y)
print('дотвидания!')

# Посложнее программа

print('дратути!')
my_family_height = [
    ['мама', 168],
    ['папа', 186],
    ['я', 200],
]
total_height = my_family_height[0][1]
total_height += my_family_height[1][1]
total_height += my_family_height[2][1]
print('Общий рост моей семьи', total_height)
print('дотвидания!')
